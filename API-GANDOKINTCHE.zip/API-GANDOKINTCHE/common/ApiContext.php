<?php
/**
 * Created by PhpStorm.
 * User: Verbeck DEGBESSE
 * Date: 16/10/2018
 * Time: 10:31
 */

class ApiContext
{
    public static function getUrl(){
        return "http://www.gandokintche.com/apirest/public/api/v1/payment";
    }
}